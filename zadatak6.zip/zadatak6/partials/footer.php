<div class="col-sm-12" style="height:150px; padding-top:60px; border:1px solid black; background-color:grey;">
Nevena Radakovic <br> 68/2019
</div>