</div>
<div class="row">
<?php include_once './partials/footer.php' ?>
</div>
    </div>
</body>
</html>