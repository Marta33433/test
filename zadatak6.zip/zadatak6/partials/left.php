<div class="col-sm-4" style="height:350px; padding-top:20px; border:1px solid black; background-color:grey;">
<form action="controllerAuto.php" method="post">
    <label for="marka">Marka</label> <br>
    <input type="text" name="marka"> <br>
    <label for="cena">Cena</label> <br>
    <input type="text" name="cena"> <br>
    <input type="submit" value="UNOS">
</form>
</div>