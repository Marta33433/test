<div class="col-sm-12" style="height:200px; padding-top:80px; border:1px solid black; background-color:grey;">
IP ispit
</div>