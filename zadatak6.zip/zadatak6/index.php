<?php include_once './partials/template1.php' ?>

<?php

$msg = isset($msg)?$msg:"";

echo $msg;

?>

<?php include_once './partials/template2.php' ?>